import React from 'react';
import { Link, useLocation } from 'react-router-dom';
import { useSelector } from 'react-redux';
import { FaCalendarDays } from "react-icons/fa6";
import { IoSchoolSharp } from "react-icons/io5";
import { MdPeopleAlt } from "react-icons/md";
export const AdminHeader = () => {
  const { currentUser } = useSelector((state) => state.user);
  const location = useLocation();

  return (

    <div className='bg-white  border border-gray-300 shadow-md h-full'>
      <div className='flex flex-col justify-between items-center p-3 mt-3'>
        <Link to='/admin-dashboard'>
          <h1 className='font-bold text-sm sm:text-xl flex flex-wrap gap-2'>
          <div className='flex gap-2 '>
          <FaCalendarDays className='bg-white text-black mt-1 ml-12' />
          <span className='text-[#64748B] '>AttendMaster</span>
          </div>
           
          </h1>
          
          <div className='bg-gray-400 mt-2 w-[250px]  h-[1px]'></div>
        </Link>

        <ul className='flex mt-10 flex-col gap-4 space-y-8  '>
          <Link
            to='/add-teacher'
            className={`${
              location.pathname === '/add-teacher' ? 'text-blue-500' : 'text-gray-600'
            }`} 
          >
            <div className='flex gap-2'>
            <MdPeopleAlt className='mt-1' />
            Manage Teacher
            </div>
           
          </Link>

          <Link
            to='/add-class'
            className={`${
              location.pathname === '/add-class' ? 'text-blue-500' : 'text-gray-600'
            }`}
          >
          <div className='flex gap-2'>
          <IoSchoolSharp className='mt-1' />

             Manage Class
          </div>
          
          </Link>

          <Link to='/profile'
          >
          
          <div className='flex gap-4'>
         

          {currentUser && (
              <img
                className='rounded-full h-7 w-7 object-cover'
                src={currentUser.avatar}
                alt='profile'
              /> 

            ) }

            <p  className={`${
              location.pathname === '/profile' ? 'text-blue-500' : 'text-gray-600'
            }`}> Profile </p>
          </div>
           
           
          </Link>
        </ul>
      </div>
    </div>
  );
};