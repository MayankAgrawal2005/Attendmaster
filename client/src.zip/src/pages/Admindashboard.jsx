import React from 'react';
import { useSelector } from 'react-redux';
import { AdminHeader } from '../components/AdminHeader';
import { FaCalendarDays } from "react-icons/fa6";
export const Admindashboard = () => {
  const { currentUser } = useSelector((state) => state.user);

  function getGreeting() {
    const currentHour = new Date().getHours();
    if (currentHour < 12) return 'Good Morning';
    if (currentHour < 18) return 'Good Afternoon';
    return 'Good Evening';
  }

  return (
    <div className='flex h-screen space-x-8'>
      {/* Left side: AdminHeader */}
      <div className='w-64 bg-slate-200 shadow-xl'>
        <AdminHeader />
      </div>

      {/* Right side: Main Content */}
      <div className='flex-1 min-h-screen border border-gray-200 shadow-2xl  bg-white p-6 text-black'>
        <div className=' flex flex-col justify-center items-center min-h-screen  space-y-6'>
          <h1 className='text-5xl'>Welcome To AttendMaster</h1>
          <p className='text-2xl font-bold'>
            {getGreeting()} {currentUser?.username}
          </p>
          <p className='mt-2 mb-10 text-xl font-mullish'>
            Select an option from the navbar to get started.
          </p>
        </div>
      </div>
    </div>
  );
};