import React from 'react'
import { Link } from 'react-router-dom'
import Lottie from 'lottie-react';
import { Header } from '../components/Header';
import { MdTableView } from "react-icons/md";
export const Home = () => {
  return (
    <div className='bg-slate-200 shadow-md h-14'>
         
    
   <Header className=''/>
  <div className='w-full h-screen relative flex items-center  justify-center  mt-4'>
  
  <div className='mx-auto space-y-3 '>
    {/* <h1 className={` text-5xl text-center font-bold  font-mullish gradient-text shadow-lg mb-4 ${isBlurred?'blur':''} `}>Revolutionize Attendance Tracking</h1> */}
    <h1 className='text-5xl text-white gradient-text mb-4'>
        Revolutionize Attendance Tracking


</h1>
    <p className='text-center  text-xl  '>"Effortless Attendance Tracking"</p>
    <div className='flex justify-center '>
  <button className='bg-yellow-400 px-3 py-3    text-black rounded-md  '>
     <Link to="/login">
     Get started
     </Link>
     
</button>
</div>
  </div>

</div>

<section id='features' className="flex justify-evenly border border-gray-300 shadow  p-10">

 <div  className='mt-2 '>
 <h1 className=' text-center text-4xl font-mullish '>Key Features</h1>
    <div className='flex flex-row  justify-between  space-x-14   mt-24'>
 {/* First Card */}
 <div className="w-[365px] h-[300px] border border-gray-300 bg-yellow-400 relative">
  <div className="absolute top-[-15px] left-[168px] transform -translate-x-1/2 w-[350px] h-[300px] bg-[#FFFFFF] border border-gray-300 hover:rotate-6 hover:scale-105 transition-all duration-300 shadow-lg">
    <div className="flex space-x-5 p-5">
      <Lottie
        style={{ width: "80px", height: "100px" }}
        // Replace with your Lottie file
      />
      <p className="mt-8 text-2xl font-mullish text-black ">
        Excel Integration
      </p>
    </div>
    <div className="mt-5 p-3">
      <p className="font-mullish text-md text-[#6E727F] leading-[1.2]">
        Automatically update and access a single, comprehensive Excel sheet.
      </p>
    </div>
  </div>
</div>

 {/* Second Card */}
 <div className="w-[365px] h-[300px] border border-gray-300 bg-yellow-400 relative">
  <div className="absolute top-[-15px] left-[168px] border border-gray-300 transform -translate-x-1/2 w-[350px] h-[300px] bg-[#FFFFFF]  hover:rotate-6 hover:scale-105 transition-all duration-300 shadow-lg">
    <div className="flex space-x-5 p-5">
    <MdTableView className='w-[60px] h-[80px] mt-3 text-blue-500 '/>
      <Lottie
        style={{ width: "80px", height: "100px" }}
        // Replace with your Lottie file
      />
      <p className="mt-8 text-2xl font-mullish text-black ">
      TimeTable Management
      </p>
    </div>
    <div className="mt-5 p-3">
      <p className="font-mullish text-md text-[#6E727F] leading-[1.2]">
      Seamlessly integrate with existing timetables or create new ones. Effortlessly manage schedules,
      </p>
    </div>
  </div>
</div>

 {/* Third Card */}

 <div className="w-[365px] h-[300px] border border-gray-300 bg-yellow-400 relative">
  <div className="absolute top-[-15px] left-[168px] border border-gray-300 transform -translate-x-1/2 w-[350px] h-[300px] bg-[#FFFFFF]  hover:rotate-6 hover:scale-105 transition-all duration-300 shadow-lg">
    <div className="flex space-x-5 p-5">
   
      <Lottie
        style={{ width: "80px", height: "100px" }}
        // Replace with your Lottie file
      />
      <p className="mt-8 text-2xl font-mullish text-black ">
      Interactive Attendance
      </p>
    </div>
    <div className="mt-5 p-3">
      <p className="font-mullish text-md text-[#6E727F] leading-[1.2]">
      Mark attendance with just a click , using out intuitive interface
      </p>
    </div>
  </div>
</div>
    </div>
 </div>

  </section>


 {/* About section */}
 <div id='about' className='w-full h-[450px]  flex justify-between  '>
  
  <div className='mt-24 flex'>
 {/* first block */}
  <div className='w-[725px] h-[300px] border shadow-2xl border-gray-300 flex items-center justify-center'>
   <p> 3D Model placeholder</p>
</div>
{/* second block */}
<div className='w-[725px] h-[300px] border  shadow-2xl border-gray-300'>
  <div className='ml-14 mt-6'>
    <h2 className=' text-3xl font-mullish '>About AttendMaster</h2>
    <p className='text-[#6E727F] mt-6 font-mullish'> AttendMaster is designed to revolutionize attendance management in educational institutions.Our digital solution
    replaces traditional paper-based methods,offering a seamless,efficient and accurate way to track student attendance</p>

    <p className='text-[#6E727F] mt-4 font-mullish'>With features like Interactive marking,automated Excel updates,and timetable integration,Trackit simplifies the entire attendance process for teachers and administrators alike</p>
  </div>
</div>
  </div>
   
</div>


{/* contact us section */}
<div id='contact' className='w-full h-[350px] border border-gray-300 flex  items-center justify-center'>
 <div className='   '>
     <h1 className=' text-center text-4xl font-bold font-mullish'>Get in Touch</h1>
     <p className=' mt-5'>Ready to transform your attendance management ? Contact us today!</p>
     <div className='flex justify-center mt-2'>
                <button className='bg-yellow-400 mt-4  px-4 py-3 text-black rounded-md  '>
                    Contact us
             </button>
      </div>
 </div>
 </div>

 <div className='w-full h-[50px] border border-gray-300'>
 <p className=' font-mullish p-3 text-center'>&copy; 2025 AttendMaster </p>
 </div>


    </div>
  )
}
