import React, { useState } from 'react';
import { Header } from '../components/Header';
import Signup from './Signup';
import { StudentLogin } from './StudentLogin';
import { TeacherLogin } from './TeacherLogin';

export const Login = () => {
  const [selectedRole, setSelectedRole] = useState('Admin');

  const renderForm = () => {
    switch (selectedRole) {
      case 'Student':
        return <StudentLogin />;
      case 'Teacher':
        return <TeacherLogin />;
      case 'Admin':
        return <Signup />;
      default:
        return <Signup />;
    }
  };

  return (
    <div className=" min-h-screen "> 
      <Header />
      
   <div className='mx-auto border border-gray-400 rounded-2xl shadow-xl mt-10 w-[500px] h-[600px]  '>

   
      <div className="flex justify-center items-start pt-8">
        <div className="flex space-x-8 border border-gray-400 p-2 rounded-full">
          {/* Student Button */}
          <button
            onClick={() => setSelectedRole('Student')}
            className={`px-6 py-2 rounded-full text-lg font-semibold transition-all duration-300 
              ${selectedRole === 'Student' ? 'bg-[#000814] text-white' : 'bg-gray-700 text-gray-400'} 
              hover:bg-[#000814]`}
          >
            Student
          </button>

          {/* Teacher Button */}
          <button
            onClick={() => setSelectedRole('Teacher')}
            className={`px-6 py-2 rounded-full text-lg font-semibold transition-all duration-300 
              ${selectedRole === 'Teacher' ? 'bg-[#000814] text-white' : 'bg-gray-700 text-gray-400'} 
              hover:bg-[#000814]`}
          >
            Teacher
          </button>

          {/* Admin Button */}
          <button
            onClick={() => setSelectedRole('Admin')}
            className={`px-6 py-2 rounded-full text-lg font-semibold transition-all duration-300 
              ${selectedRole === 'Admin' ? 'bg-[#000814] text-white' : 'bg-gray-700 text-gray-400'} 
              hover:bg-[#000814]`}
          >
            Admin
          </button>
        </div>
      </div>

      {/* Render the selected form */}
      <div className="mt-4 flex justify-center ">
        <div className="w-full max-w-md bg-white p-8 border border-gray-400  rounded-lg shadow-lg shadow-gray-400"> {/* White background for the form */}
        {renderForm()}
        </div>
      </div>

</div>

    </div>
  );
};

