import React, { useState,useEffect } from 'react'
import { AdminHeader } from '../components/AdminHeader';
import { MdCancel } from "react-icons/md";

import { useSelector } from 'react-redux';
import { Link } from 'react-router-dom';
export const TeacherRoute = () => {
    
     const {currentUser} = useSelector(state=>state.user);
    const [loading,setLoading]=useState(false);
    const [error,setError]=useState(false);
    const [refresh, setRefresh] = useState(false);
    const [isModalOpen, setIsModalOpen] = useState(false); 
    const [formData,setFormData] = useState({
        name:'',
        email:'',
    })
   const adminId = currentUser._id;
   console.log('admin ID is',adminId);
    console.log('current user is',currentUser);

    const [teachers,setTeachers]=useState([]);

    const handleChange=(e)=>{
        setFormData({
            ...formData,
            [e.target.id]:e.target.value,
        })
    }


    const handleSubmit = async(e)=>{
        e.preventDefault();

        try{

            setLoading(true);
            const res = await fetch('/api/teacher/add-teacher',{

                method:'POST',
                headers:{
                    'Content-Type':'application/json',

                },
                body:JSON.stringify({
                   ... formData,
                   adminId,
                }
                 
                ),

            });

            const data = await res.json();
            if(data.success===false){
             setLoading(false);
             setError(data.message);
           
             return;
            }

            // loading
      setLoading(false);
      setError(null);
      setIsModalOpen(false);
      setRefresh(prev => !prev);

     console.log(data);

        }catch(error){

            setLoading(false);
            setError(error.message);

        }


    }

    console.log("formData is ", formData);


    const fetchTeachers = async()=>{
        try{

            const res = await fetch(`/api/teacher/get-teachers/${adminId}`);
            const data = await res.json();
            setTeachers(data);

        }catch(error){

            setError("Failed to load teachers"); 
          
            setTimeout(() => {
              setError("");
          }, 3000);
      
          }
    }

    useEffect(() => {
        fetchTeachers();
    }, [refresh]);

    console.log("teachers is ",teachers);

  return (

    <div className='flex  space-x-8'>

   <div className='w-64 overflow-y-auto bg-slate-200  shadow-xl'>
        <AdminHeader />
      </div>
    
    {/* right side */}
 <div className='flex-1 min-h-screen border border-gray-200 shadow-2xl  bg-white p-6 text-black'>


 <div className='flex justify-between'>
 <h1 className='text-2xl mt-2'>Teacher Management</h1>

<button
         onClick={() => setIsModalOpen(true)}
         className='bg-blue-500 text-white w-[200px] h-[60px] p-2 rounded-lg hover:bg-blue-600'
       >
        +  Add Teacher
       </button>
 </div>


 
   <main className='p-3 min-h-screen flex  bg-white ' >
  



 {/* left side  */}
{isModalOpen && (


<div className='fixed inset-0  bg-opacity-100 '>

<div className='fixed inset-0 flex justify-center items-center'>


<div className=' p-6  rounded-lg w-[500px]'>


<div className=' mt-14 ml-10 max-w-[550px] w-[480px] h-[425px] bg-white border-black rounded-3xl border mr-2'>
<form onSubmit={handleSubmit} >

<div className='ml-100'>
<button className='p-2  '
onClick={()=>setIsModalOpen(false)}>
<MdCancel className=' w-[24px] h-[40px]' />
</button>
</div>


<h1 className=' p-2 ml-5 text-2xl '> Add new Teacher</h1>
<p className='ml-6 text-gray-500'>Enter the details of the new Teacher below</p>

<div className='flex flex-col p-2 ml-10 mt-8 gap-4 border-white rounded-lg  '>
          {/* <label className='text-xl mt-1  text-white mb-4'> Teacher Name:</label> */}
          <input
            type='text'
            maxLength={30}
            placeholder='name' id='name' onChange={handleChange}
            
           
            className='w-[350px] italic text-black border  border-black text-xl p-2 rounded-md ml-2 mb-4'
          />

       {/* <label className='text-xl mt-1  text-white mb-4'>Email:</label> */}
          <input
            type='text'
            maxLength={50}
            placeholder='email' id='email' onChange={handleChange}
            
           
            className='w-[350px] italic border  border-black text-black bg-white text-xl p-2 rounded-md ml-2 mb-4'
          />
        </div>


<div className='ml-14 mt-3  '>
 <button disabled={loading} className='bg-blue-500 text-bold text-white p-3 w-[350px] rounded-lg uppercase text-center hover:opacity-95 ' >
       {loading ? 'Saving': 'Add Teacher'}
     </button>

</div>

</form>

   </div>

   </div>

</div>
</div>
)}





   <div className='flex flex-col  w-full gap-4'>

  <div className="mt-10 p-3 w-full h-full text-white border border-gray-300 rounded-2xl  ">
                    <h2 className="text-2xl text-black p-3">Teachers directory</h2>
                    <p className='text-gray-400 p-3'>Manage and view all teachers in the system</p>

                    {error && <p className='text-red-500 mt-5' >{error}</p>}
                    {teachers.length === 0 ? (
                        <p>No teachers added yet.</p>

                    ) : (
                       
                      <table className='w-full ml-2 overflow-x-scroll border  border-gray-300  bg-white  shadow-md'>
      {/* Table Header */}
      <thead className=' text-gray-600  border border-gray-300'>
        <tr>
          <th className='p-3 text-left'>Name</th>
          <th className='p-3 text-left'>Email</th>
          <th className='p-3 text-left'>Actions</th>
          <th className='p-3 text-left'>Code</th>
          <th className='p-3 text-left'>Password</th>
        </tr>
      </thead>

      {/* Table Body */}
      <tbody>
        {teachers.map((teacher, index) => (
          <tr
            key={index}
            className='border-b border-gray-200 hover:bg-gray-50 transition-colors'
          >
           
            <td className='p-3 text-black'>{teacher.name}</td>

            
            <td className='p-3 text-black'>{teacher.email}</td>

            {/* Actions (Update and Assign) */}
            <td className='p-3 flex items-center space-x-2'>
              {/* Update Button */}
              <Link to={`/update-teacher/${teacher._id}`}>
                <button className='bg-gray-200 hover:bg-gray-700 text-black hover:text-white p-2 rounded transition'>
                  Update
                </button>
              </Link>

              {/* Assign Button */}
              
            </td>
            <td className='p-3 text-black'>{teacher.code}</td>
            <td className='p-3 text-black'>{teacher.password}</td>

          </tr>
        ))}
      </tbody>
    </table>
                
                                                  )}
     </div>

   </div>
  


    </main>
    </div>

    
    </div>
  )
}
